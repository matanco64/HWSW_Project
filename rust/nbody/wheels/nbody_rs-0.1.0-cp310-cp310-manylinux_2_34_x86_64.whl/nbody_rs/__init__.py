from .nbody_rs import *

__doc__ = nbody_rs.__doc__
if hasattr(nbody_rs, "__all__"):
    __all__ = nbody_rs.__all__