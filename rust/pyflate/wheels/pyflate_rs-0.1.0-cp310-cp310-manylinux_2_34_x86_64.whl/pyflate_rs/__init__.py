from .pyflate_rs import *

__doc__ = pyflate_rs.__doc__
if hasattr(pyflate_rs, "__all__"):
    __all__ = pyflate_rs.__all__